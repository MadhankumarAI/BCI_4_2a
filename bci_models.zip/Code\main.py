import numpy as np
from pathlib import Path
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.metrics import accuracy_score, cohen_kappa_score
import warnings

from data_loader import load_and_epoch_data, load_true_labels
from preprocessing import apply_filter_bank, common_average_reference
from fbcsp import FBCSP

# Suppress some potential sklearn warnings about rank-deficient covariance matrices during CV
warnings.filterwarnings("ignore")

def main():
    data_dir = Path(r"c:\Users\jaip7\Downloads\madhan\BCI\BCICIV-2a-mat")
    labels_dir = Path(r"c:\Users\jaip7\Downloads\madhan\BCI\true_labels")
    
    subjects = [f"A0{i}" for i in range(1, 10)]
    accuracies = []
    kappas = []
    
    # 0.5s to 4.0s after cue (which is 2.5s to 6.0s relative to trial start)
    start_sec = 2.5
    end_sec = 6.0
    
    print(f"Running FBCSP Pipeline with Optimal Window: {start_sec-2.0}s to {end_sec-2.0}s post-cue")
    print("-" * 50)
    
    for subject in subjects:
        print(f"Processing Subject {subject}...")
        
        train_file = data_dir / f"{subject}T.mat"
        test_file = data_dir / f"{subject}E.mat"
        true_labels_file = labels_dir / f"{subject}E.mat"
        
        # --- Training ---
        X_train_raw, y_train, _ = load_and_epoch_data(train_file, start_sec=start_sec, end_sec=end_sec)
        
        # Apply Common Average Reference (CAR)
        X_train_car = common_average_reference(X_train_raw)
        
        # Apply Filter Bank
        X_train_fb = apply_filter_bank(X_train_car)
        
        # Setup Pipeline with FBCSP and Shrinkage LDA
        pipeline = Pipeline([
            ('fbcsp', FBCSP()),
            ('scaler', StandardScaler()),
            ('lda', LDA(solver='lsqr', shrinkage='auto'))
        ])
        
        # Grid Search for best k_features and m_components using inner Cross-Validation
        param_grid = {
            'fbcsp__k_features': [4, 6, 8, 10, 12, 16],
            'fbcsp__m_components': [2, 4, 6]
        }
        
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        grid_search = GridSearchCV(pipeline, param_grid, cv=cv, scoring='accuracy', n_jobs=1)
        
        # Fit Grid Search
        grid_search.fit(X_train_fb, y_train)
        best_model = grid_search.best_estimator_
        
        print(f"  Best params: {grid_search.best_params_}")
        
        # --- Evaluation ---
        X_test_raw, _, test_indices = load_and_epoch_data(test_file, start_sec=start_sec, end_sec=end_sec)
        
        # Load true labels for evaluation
        y_test_all = load_true_labels(true_labels_file)
        
        # Align evaluation labels with the kept trials (non-artifacts)
        y_test_all = y_test_all[test_indices]
        
        # Filter evaluation trials to only Class 1 (Left) and Class 2 (Right)
        mask = (y_test_all == 1) | (y_test_all == 2)
        X_test_raw_filtered = X_test_raw[mask]
        y_test = y_test_all[mask]
        
        # Apply CAR and Filter Bank
        X_test_car = common_average_reference(X_test_raw_filtered)
        X_test_fb = apply_filter_bank(X_test_car)
        
        # Predict and evaluate
        y_pred = best_model.predict(X_test_fb)
        acc = accuracy_score(y_test, y_pred)
        kappa = cohen_kappa_score(y_test, y_pred)
        
        accuracies.append(acc)
        kappas.append(kappa)
        
        print(f"  Accuracy: {acc*100:.2f}% | Kappa: {kappa:.4f}")
        
    print("-" * 50)
    print(f"Mean Accuracy: {np.mean(accuracies)*100:.2f}%")
    print(f"Mean Kappa: {np.mean(kappas):.4f}")

if __name__ == "__main__":
    main()
